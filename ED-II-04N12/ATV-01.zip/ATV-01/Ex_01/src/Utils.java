public class Utils {

    public static void mostaMennsagem(ResultadoOperacao mensagem) {

        System.out.println(String.valueOf(mensagem.msg) + "\n");

    }

}

